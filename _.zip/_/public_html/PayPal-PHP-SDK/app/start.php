<?php



require_once $_SERVER['DOCUMENT_ROOT'] . '/PayPal-PHP-SDK/autoload.php';
$config = parse_ini_file('/storage/ssd3/476/6694476/private/config.ini'); 
$client = 'clientID_';
$secret = 'secret_';
$env = $config['environment'];

$client = $client . $env;
$secret = $secret . $env;

define('SITE_URL', 'https://gobigtipper.000webhostapp.com/');

$paypal = new \PayPal\Rest\ApiContext(
        new \PayPal\Auth\OAuthTokenCredential(
            $config[$client],
            //'Ac5KPrqzANueOYdClsJv2L0M_fH-AfhfP80VQrasJKzIzEPaoxtUW7PUuC6AWklAGdiZ16MoC7JIdzoy',     // ClientID
            $config[$secret] 
            //'EDdTEcE2n7VLdbIfHgvRHXN4QlLSxK-PrrFt2MAeZYbCHPFy7gQUWn-12gncPeeDZp6sN0onTWHkF1Ae'      // ClientSecret
        )
);

$paypal->setConfig(
      array(
        'mode' => 'live',
      )
);
?>