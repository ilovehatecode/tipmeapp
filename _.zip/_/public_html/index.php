<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Big Tipper : Send money your way</title>

    <!-- Bootstrap core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="/css/jumbotron-narrow.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <?php include "functions.php" ?>
      
    <![endif]-->
    <script src="https://js.stripe.com/v3/"></script>
    

  </head>

  <body>

    <div class="container">
        
       
      <div class="header clearfix">
      <div class="col-md-12 text-center">
            <h3 class="text-muted">Big Tipper</h3>
        </div>
         <!--
        <nav>
        
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="#">Home</a></li>
            <li role="presentation"><a href="#">About</a></li>
          </ul>
        </nav> 
        <h3 class="text-muted">Big Tipper</h3>-->
      </div>
      <div class="row marketing">
        <div class="col-lg-6">
          <h4>Send Money</h4>
          <p>Choose the amount, the way you want to pay, and to whom you want to pay by entering their <b>Big Tipper</b> account or the email associated with the payment service (i.e. Paypal).</p>

        </div>
        <div class="col-lg-6">
          <h4>Receive Money</h4>
          <p>Click <a href="business.php">here</a> to set up an account and let your fans or customers pay you howerver they want.</p>

         </div>

      </div>    
      <div class="jumbotron">
        <h2>Make a payment</h2>
        <form action="payment.php" method="POST">
            <div class="row">
                <div class="col-md-6">
                    <p>Amount</p>
                    <input type="number" step="1" value="3" id="amount" name="amount" size="4" min="1" max="100">
                </div>
                
                <div class="col-md-6">
                    <p>Payee</p>
                    <input type="text" name="payee" >
                </div>
            </div>
                <div class="row spaced-element">
                 <div class="col-md-12" align="center">
                     <p>Choose Payment Option</p>
                     <div class="input-group mb-3">
                      <select class="custom-select" id="inputGroupSelect02" name="paymentoption">
                        
                        <?php foreach(get_payment_options() as $option) {
                            echo $option['code'];
                        } ?> 
                      </select>
                       
                    </div>
                 </div>
                 </div>
                 <div class="row">
                <div class="col-md-12" align="center">
                    <?php 
                        $error_message_list = array( '1' => 'Invalid payee');
                        if(isset($_GET['error_num'])) {
                            $error_num  = $_GET['error_num'];
                            $error_msg = '';
                            if(isset($error_num) ) {
                                if(!empty($error_message_list[$error_num])) {
                                    $error_msg = $error_message_list[$error_num];
                                }
                                else {
                                    $error_msg = 'Unknown Error';
                                }
                                echo '<p>' . $error_msg . '. Try again.</p>';
                            }
                       
                        }
                    ?> <br>
                 <input type="submit" value="Pay" class="btn btn-lg btn-success">
                </div>
                </div>
            
            
                
            
           
           
        </form>
        
      </div>

      
       <footer class="footer">
           <div id="payment-request-button">
  <!-- A Stripe Element will be inserted here. -->
</div>
        <p>&copy; 2015 Walker Ventures, LLC.</p>
      </footer>

    </div> <!-- /container -->


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="/js/stripe-payment.js"></script>
  </body>
</html>
