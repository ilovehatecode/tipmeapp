<?php
if($_POST['paymentoption'] === 'paypal') {
    include "paypal-payment.php";
}
?>