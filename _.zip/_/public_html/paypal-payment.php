<?php
//require __DIR__  . '/PayPal-PHP-SDK/autoload.php';
require "functions.php";
//require "PayPal-PHP-SDK/app/start.php";
use PayPal\Api\Amount;
use PayPal\Api\Details;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\Payee;
use PayPal\Api\Payer;
use PayPal\Api\Payment;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Transaction;

  

  
$payee_check = $_POST['payee'];
//echo $payee_check;
if (!filter_var($payee_check, FILTER_VALIDATE_EMAIL)) {
  $payee_check = get_merchant_identifier($_POST['payee'], 'paypal' );
  if($payee_check == 'None') {
      header("Location: " . SITE_URL . '?error_num=1', true, 301);
      die();
  }
}
//echo $payee_check;


$payer = new \PayPal\Api\Payer();
$payer->setPaymentMethod('paypal');

$amount = new \PayPal\Api\Amount();
$total = $_POST['amount'];
$amount->setTotal($total);
$amount->setCurrency('USD');


$payee = new Payee();
$payee_email = $payee_check;
$payee->setEmail($payee_email);
$transaction = new \PayPal\Api\Transaction();
$transaction->setAmount($amount)
    ->setPayee($payee);

$redirectUrls = new \PayPal\Api\RedirectUrls();
$redirectUrls->setReturnUrl(SITE_URL . "process-payment.php?success=true")
    ->setCancelUrl(SITE_URL . "process-payment.php?success=false");

$payment = new \PayPal\Api\Payment();
$payment->setIntent('sale')
    ->setPayer($payer)
    ->setTransactions(array($transaction))
    ->setRedirectUrls($redirectUrls);

try {
    $payment->create($paypal);
   // echo $payment;
    
    //echo "\n\nRedirect user to approval_url: " . $payment->getApprovalLink() . "\n";
    
}
catch (\PayPal\Exception\PayPalConnectionException $ex) {
    // This will print the detailed information on the exception.
    //REALLY HELPFUL FOR DEBUGGING
    echo $ex->getData();
    die();
}
$approvalUrl = $payment->getApprovalLink();
//echo $approvalUrl;
header("Location: {$approvalUrl}", true, 301);
exit();
?>