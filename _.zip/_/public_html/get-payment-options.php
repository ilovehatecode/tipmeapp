<?php
    require "functions.php";
    
    display_payment_options();
    /*
    $string = file_get_contents(SITE_URL . "data/paymentoptions.json");
    $json = json_decode($string, true);
    foreach($json as $option) {
        echo $option['code'];
    }
    */
    
?> 