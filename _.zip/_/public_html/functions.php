<?php
    require 'PayPal-PHP-SDK/app/start.php';
    /* 
        Get payment options in json format
    */
    
    function get_data($url) {
        $string = file_get_contents(SITE_URL . $url);
        $json = json_decode($string, true);
        return $json;
    }
    
    function get_payment_options() {
        $string = file_get_contents(SITE_URL . "data/paymentoptions.json");
        $json = json_decode($string, true);
        return $json;
    }
   

    function get_merchant_identifier($username, $payoption) {
        $data = get_data("data/business-user.json");
        if(!empty($data[$username][$payoption]) ) {
            return $data[$username][$payoption];
        }
        else {
            return 'None';
        }
    }
    
?>