<?php
require_once __DIR__ . "/stripe-php/init.php";
\Stripe\Stripe::setApiKey("sk_test_w9AikrJZNJD45PY4OYYG6JNX");

// Token is created using Checkout or Elements!
// Get the payment token ID submitted by the form:
$postdata = file_get_contents("php://input"); 
$jsonArray = json_decode($postdata);
$token = $jsonArray->token;
$charge = \Stripe\Charge::create([
    'amount' => 999,
    'currency' => 'usd',
    'description' => 'Example charge',
    'source' => $token,
    'statement_descriptor' => 'Custom descriptor',
]);

?> 
